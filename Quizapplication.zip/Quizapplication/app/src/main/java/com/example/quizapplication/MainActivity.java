package com.example.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.quizapplication.tests.TestActivity;



public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    public static int rightAnswer;



    Button testActivity;
    Button startLearnActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar tb = findViewById(R.id.tb);
        setSupportActionBar(tb);


        testActivity = (Button) findViewById(R.id.test_your_level);
        testActivity.setOnClickListener(this);
        startLearnActivity = (Button) findViewById(R.id.start_learn);
        startLearnActivity.setOnClickListener(this);



    }


    private Boolean exit = false;
    @Override
    public void onBackPressed() {
        if (exit) {
            finish();
        } else {
            Toast.makeText(this, "Press Back again to Exit.",
                    Toast.LENGTH_SHORT).show();
            exit = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    exit = false;
                }
            }, 3 * 1000);

        }

    }
    @Override
    protected void onStart(){
        super.onStart();
        Variables.rightAnswer = 0;
    }
    public void onClick(View v){
        switch (v.getId()){
            case R.id.test_your_level:
                Intent intent = new Intent(this, TestActivity.class);
                startActivity(intent);
                break;
            case R.id.start_learn:
                intent = new Intent(this, LearnActivity.class);
                startActivity(intent);
                break;

        }

    }





}
